-- ============================================================
-- Darula Transporte – Datenbank-Umbau (Supabase SQL Editor)
--
-- Ausführen in dieser Reihenfolge: Abschnitt 1, dann 2, dann 3.
-- Vorher in Abschnitt 2 die E-Mail des Verwalters eintragen.
-- Der Verwalter muss vorher unter Authentication → Users angelegt sein.
-- Der Befehl ist mehrfach ausführbar.
-- ============================================================


-- ============================================================
-- ABSCHNITT 1: Buchung und Verfügbarkeit
-- ============================================================

-- Verfügbarkeit: liefert nur Zählwerte ohne Personendaten
create or replace function public.verfuegbarkeit_avisierung(p_von date)
returns table (datum date, grosse_lieferungen integer)
language sql
stable
security definer
set search_path = public
as $$
  select a.liefer_datum, count(*)::integer
  from public.avisierung a
  where a.liefer_datum >= greatest(p_von, (now() at time zone 'Europe/Berlin')::date)
    and a.palettes >= 20
  group by a.liefer_datum;
$$;

revoke all on function public.verfuegbarkeit_avisierung(date) from public;
grant execute on function public.verfuegbarkeit_avisierung(date) to anon, authenticated;

-- Buchung: alle Prüfungen serverseitig, transaktionssicher
create or replace function public.buche_avisierung(
  p_liefer_datum date,
  p_firma text,
  p_email text,
  p_palettes integer,
  p_be_nummer text,
  p_lieferschein_pfad text default null
)
returns table (ergebnis_avis_id text, ergebnis_datum date)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_heute date := (now() at time zone 'Europe/Berlin')::date;
  v_gross integer;
  v_avis_id text;
  v_versuche integer := 0;
begin
  if p_firma is null or length(trim(p_firma)) < 2 or length(p_firma) > 100 then
    raise exception 'Bitte geben Sie eine Speditionsfirma an (2 bis 100 Zeichen).';
  end if;
  if p_email is null or length(p_email) > 254 or p_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'Bitte geben Sie eine gültige E-Mail-Adresse an.';
  end if;
  if p_palettes is null or p_palettes < 1 or p_palettes > 200 then
    raise exception 'Die Anzahl der Paletten muss zwischen 1 und 200 liegen.';
  end if;
  if p_be_nummer is null or length(trim(p_be_nummer)) < 1 or length(p_be_nummer) > 50 then
    raise exception 'Bitte geben Sie eine BE-Nummer oder Referenz an.';
  end if;
  if p_lieferschein_pfad is not null and length(p_lieferschein_pfad) > 300 then
    raise exception 'Der Lieferschein konnte nicht zugeordnet werden. Bitte versuchen Sie es erneut.';
  end if;

  if p_liefer_datum is null or p_liefer_datum < v_heute then
    raise exception 'Bitte wählen Sie einen heutigen oder zukünftigen Tag.';
  end if;
  if extract(isodow from p_liefer_datum) > 5 then
    raise exception 'An Wochenenden findet keine Warenannahme statt.';
  end if;
  if p_liefer_datum = date '2026-11-11' then
    raise exception 'Am 11.11.2026 findet die Inventur statt. Die Warenannahme ist an diesem Tag geschlossen.';
  end if;

  -- Buchungen für denselben Tag nacheinander abarbeiten
  perform pg_advisory_xact_lock(hashtext('avisierung:' || p_liefer_datum::text));

  -- Große Lieferungen ab 20 Paletten: höchstens drei pro Tag
  if p_palettes >= 20 then
    select count(*) into v_gross
    from public.avisierung
    where liefer_datum = p_liefer_datum and palettes >= 20;
    if v_gross >= 3 then
      raise exception 'An diesem Tag sind alle drei Plätze für Lieferungen ab 20 Paletten belegt. Bitte wählen Sie einen anderen Tag oder eine Anzahl unter 20 Paletten.';
    end if;
  end if;

  loop
    v_avis_id := 'DAR-' || to_char(v_heute, 'YYMMDD') || '-'
                 || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 4));
    exit when not exists (select 1 from public.avisierung a where a.avis_id = v_avis_id);
    v_versuche := v_versuche + 1;
    if v_versuche >= 10 then
      raise exception 'Die Buchungsnummer konnte nicht erzeugt werden. Bitte versuchen Sie es erneut.';
    end if;
  end loop;

  insert into public.avisierung
    (liefer_datum, firma, email, palettes, be_nummer, lieferschein_url, status, avis_id)
  values
    (p_liefer_datum, trim(p_firma), lower(trim(p_email)), p_palettes, trim(p_be_nummer), p_lieferschein_pfad, 'gebucht', v_avis_id);

  return query select v_avis_id, p_liefer_datum;
end;
$$;

revoke all on function public.buche_avisierung(date, text, text, integer, text, text) from public;
grant execute on function public.buche_avisierung(date, text, text, integer, text, text) to anon, authenticated;


-- ============================================================
-- ABSCHNITT 2: Verwalter und Zugriffsregeln
-- ============================================================

-- Liste der Verwalter (nur über die Datenbank lesbar)
create table if not exists public.admin_nutzer (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.admin_nutzer enable row level security;
revoke all on public.admin_nutzer from anon, authenticated;

-- Prüft, ob das angemeldete Konto Verwalter ist
create or replace function public.ist_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.admin_nutzer where user_id = auth.uid());
$$;

revoke all on function public.ist_admin() from public;
grant execute on function public.ist_admin() to authenticated;

-- Alle bisherigen Regeln der Tabelle entfernen
do $$
declare r record;
begin
  for r in select policyname from pg_policies where schemaname = 'public' and tablename = 'avisierung' loop
    execute format('drop policy %I on public.avisierung', r.policyname);
  end loop;
end $$;

alter table public.avisierung enable row level security;

-- Besucher haben keinen direkten Zugriff auf die Tabelle.
-- Verwalter dürfen lesen, ändern und löschen, aber nur mit Verwalterrecht.
revoke all on public.avisierung from anon, authenticated;
grant select, update, delete on public.avisierung to authenticated;

create policy "Verwalter: lesen" on public.avisierung
  for select to authenticated using (public.ist_admin());

create policy "Verwalter: ändern" on public.avisierung
  for update to authenticated using (public.ist_admin()) with check (public.ist_admin());

create policy "Verwalter: löschen" on public.avisierung
  for delete to authenticated using (public.ist_admin());

-- HIER die E-Mail des Verwalters eintragen
insert into public.admin_nutzer (user_id)
select id from auth.users where email = 'DEINE-EMAIL@BEISPIEL.de'
on conflict do nothing;


-- ============================================================
-- ABSCHNITT 3: Lieferschein-Speicher
-- ============================================================

update storage.buckets
set public = false,
    file_size_limit = 10485760,
    allowed_mime_types = array['application/pdf', 'image/jpeg', 'image/png']
where id = 'lieferscheine';

-- Alte Regeln für den Lieferschein-Bucket entfernen
do $$
declare r record;
begin
  for r in select policyname from pg_policies
           where schemaname = 'storage' and tablename = 'objects'
             and (coalesce(qual, '') ilike '%lieferscheine%' or coalesce(with_check, '') ilike '%lieferscheine%')
  loop
    execute format('drop policy %I on storage.objects', r.policyname);
  end loop;
end $$;

-- Besucher dürfen Lieferscheine nur hochladen
create policy "Lieferschein hochladen (anonym)" on storage.objects
  for insert to anon with check (bucket_id = 'lieferscheine');

-- Verwalter dürfen Lieferscheine öffnen
create policy "Verwalter: Lieferscheine lesen" on storage.objects
  for select to authenticated using (bucket_id = 'lieferscheine' and public.ist_admin());


-- ============================================================
-- PRÜFUNG (optional)
-- ============================================================

-- Zeigt die Verwalter-Zeile. Muss genau eine Zeile liefern.
select * from public.admin_nutzer;

-- Verfügbarkeit. Eine leere Liste ist in Ordnung.
select * from public.verfuegbarkeit_avisierung(current_date);

-- Schema der Schnittstelle neu laden
notify pgrst, 'reload schema';
